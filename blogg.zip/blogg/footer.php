<div class="container wrap">

    <div class="row">
        <div class="col-md-12">
            <p>&copy; <?php  echo Date("Y"); ?> Ahmad Ryzal Ikhsani</p>
        </div>
    </div>
</div>
