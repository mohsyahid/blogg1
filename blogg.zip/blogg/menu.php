<div class="container wrap">
    <div class="row">
        <div class="col-md-12">

            <ol class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="admin/login.php">Login</a></li>
            </ol>

        </div>
    </div>
</div>
